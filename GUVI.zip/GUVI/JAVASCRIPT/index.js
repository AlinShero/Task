var x= document.getElementById("login");
var y= document.getElementById("register");
var z= document.getElementById("btn");

function register(){
    x.style.left="-400px";
    y.style.left="50px";
    z.style.left="100px"; //background color
}
function login(){
    x.style.left="40px";
    y.style.left="450px";
    z.style.left="0px"; //background color
}



